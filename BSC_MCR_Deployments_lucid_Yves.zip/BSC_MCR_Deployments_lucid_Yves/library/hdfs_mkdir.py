#! /usr/bin/env python

# @Author: Missaoui Ahmed
# @Date:   2018-07-26T14:10:08+02:00
# @Email:  ahmed.missaoui-ext@socgen.com
# @Filename: hdfs_mkdir.py

from ansible.module_utils.basic import AnsibleModule
from subprocess import Popen, PIPE

ANSIBLE_METADATA = {
    "metadata_version": "1.0",
    "supported_by": "community",
    "status": ["preview"],
    "version": "1.0.0"
}

DOCUMENTATION = """
---
module: hdfs_mkdir
short_description: Set attributes of files in the hadoop file system
description:
    - This module allows to create a directory on HDFS
version_added: "2.2"
author: Missaoui Ahmed (X171290)
options:
    path:
        description:
            - If `command`, this module will manage with the hdfs CLI.
            - If `library`, this module will use the python package `hdfs`.
        default: command
        choices:
            - command
            - library
notes:
    - method `library` not yet supported
"""

EXAMPLES = """

- name: Create folder on hdfs
  hdfs_mkdir:
    path: /tmp/myfolder

"""

# ---------------------------------------------------------------------------#
# ----------------------------------------------------------------- HdfsUtils #
# --------------------------------------------------------------------------- #

"""
Catchable class to handle the Exception of this bundle
"""


class HdfsUtilsError(Exception):
    pass

# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextCli #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using CLI to manage the file system.
All Exception will be raised with the class `HdfsUtilsError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- mkdir: create an hdfs folder
"""


class HdfsContextCli:

    def __init__(self, command="/bin/hdfs"):
        """
        The param :command: allow to change the CLI path, it's not common
        to set this parameter.
        """
        self.cmd = command

    def mkdir(self, path):
        """
        Change the :mode: of the given :path:. The param :mode: needs to
        be a string representation of an octal number (eg. "0744")
        """
        cmd = [self.cmd, "dfs", "-mkdir", "-p", path]
        proc = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        out, err = proc.communicate()
        if proc.wait() is not 0:
            HdfsUtilsError("subprocess chmod stderr: %s" % err)

        return {'stdout': out, 'stderr': err}


# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextLib #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using library to manage the file system.
All Exception will be raised with the class `HdfsContextLibError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- mkdir: create a directory
- remove: delete a file/directory
- stats: get informations about a file/directory
- touch: create file or update file access
"""


def main():
    module_args = dict(
            path=dict(type='str', required=True)
           )

    module = AnsibleModule(argument_spec=module_args)

    params = module.params
    context = HdfsContextCli()
    result = context.mkdir(params['path'])

    module.exit_json(changed=True, result=result)


if __name__ == '__main__':
    main()
