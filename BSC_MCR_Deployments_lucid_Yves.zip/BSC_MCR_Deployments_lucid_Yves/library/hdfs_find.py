#! /usr/bin/env python
from ansible.module_utils.basic import AnsibleModule
from subprocess import Popen, PIPE


# --------------------------------------------------------------------------- #
# ----------------------------------------------------------------- HdfsUtils #
# --------------------------------------------------------------------------- #

"""
Catchable class to handle the Exception of this bundle
"""


class HdfsUtilsError(Exception):
    pass

# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextCli #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using CLI to manage the file system.
All Exception will be raised with the class `HdfsUtilsError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- chmod: change file/directory right mode
- chown: change file/directory owner/group
- mkdir: create a directory
- remove: delete a file/directory
- setrep: set a file/directory replication factor
- stats: get informations about a file/directory
- touch: create file or update file access
"""


class HdfsContextCli:

    def __init__(self, command="/bin/hdfs"):
        """
        The param :command: allow to change the CLI path, it's not common
        to set this parameter.
        """
        self.cmd = command

    def ls(self, path):
        """
        List files given :path:.
        """
        cmd = [self.cmd, "dfs", "-ls",  path]
        proc = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        out, err = proc.communicate()
        if proc.wait() is not 0:
            raise HdfsUtilsError("subprocess setrep stderr: %s" % err)
        out = out.splitlines()
        keys = ['permissions', 'numberOfReplica', 'userId', 'groupId', 'sizeOfFile', 'modificationDate', 'hour', 'fileName']
        result_list = []
        for line in out[1:]:  # Fill the dict
            result_list.append(dict(zip(keys, line.strip().split())))
        return result_list


# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextLib #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using library to manage the file system.

All Exception will be raised with the class `HdfsContextLibError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- mkdir: create a directory
- remove: delete a file/directory
- stats: get informations about a file/directory
- touch: create file or update file access
"""


# --------------------------------------------------------------------------- #
# ------------------------------------------------------------- HdfsCheckMode #
# --------------------------------------------------------------------------- #

def main():
    module_args = dict(
            path=dict(type='str', required=True)
           )

    module = AnsibleModule(argument_spec=module_args)
    params = module.params
    context = HdfsContextCli()
    result = context.ls(params['path'])

    module.exit_json(result=result)


if __name__ == '__main__':
    main()
