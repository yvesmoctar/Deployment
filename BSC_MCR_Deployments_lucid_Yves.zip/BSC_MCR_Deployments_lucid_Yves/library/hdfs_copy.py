#! /usr/bin/env python

# @Author: Bruno FIDELIN
# @Date:   2018-01-24T14:10:08+02:00
# @Email:  bruno.fidelih-ext@socgen.com
# @Filename: hdfs_copy.py
# @Last modified by:   Bruno FIDELIN
# @Last modified time: 2018-01-19T14:17:43+02:00

from ansible.module_utils.basic import AnsibleModule
from subprocess import Popen, PIPE

ANSIBLE_METADATA = {
    "metadata_version": "1.0",
    "supported_by": "community",
    "status": ["preview"],
    "version": "1.0.0"
}

DOCUMENTATION = """
---
module: hdfs_copy
short_description: Set attributes of files in the hadoop file system
description:
    - This module allows copy to hdfs directory
version_added: "2.2"
author: Bruno FIDELIN (X093744)
options:
    src:
        description:
            - Name of the group that should own the
            - file/directory, as would be fed to chown.
    dest:
        description:
            - If `command`, this module will manage with the hdfs CLI.
            - If `library`, this module will use the python package `hdfs`.
        default: command
        choices:
            - command
            - library
notes:
    - method `library` not yet supported
"""

EXAMPLES = """

- name: Copy folder to hdfs
  hdfs_copy:
    src: /tmp/myfolder
    dest: directory

"""

# ---------------------------------------------------------------------------#
# ----------------------------------------------------------------- HdfsUtils #
# --------------------------------------------------------------------------- #

"""
Catchable class to handle the Exception of this bundle
"""


class HdfsUtilsError(Exception):
    pass

# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextCli #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using CLI to manage the file system.
All Exception will be raised with the class `HdfsUtilsError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- copy: copy to hdfs folder
"""


class HdfsContextCli:

    def __init__(self, command="/bin/hdfs"):
        """
        The param :command: allow to change the CLI path, it's not common
        to set this parameter.
        """
        self.cmd = command

    def copy(self, src, dest):
        """
        Change the :mode: of the given :path:. The param :mode: needs to
        be a string representation of an octal number (eg. "0744")
        """
        cmd = [self.cmd, "dfs", "-put", "-f", src, dest]
        proc = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        out, err = proc.communicate()
        if proc.wait() is not 0:
            HdfsUtilsError("subprocess chmod stderr: %s" % err)

        return {'stdout': out, 'stderr': err}


# --------------------------------------------------------------------------- #
# ------------------------------------------------------------ HdfsContextLib #
# --------------------------------------------------------------------------- #


"""
This module give an hdfs context using library to manage the file system.
All Exception will be raised with the class `HdfsContextLibError` but
the common usage is to catch `HdfsUtilsError`.

Public methods short descriptions:
- mkdir: create a directory
- remove: delete a file/directory
- stats: get informations about a file/directory
- touch: create file or update file access
"""


def main():
    module_args = dict(
            src=dict(type='str', required=True),
            dest=dict(type='str', required=True)
           )

    module = AnsibleModule(argument_spec=module_args)

    params = module.params
    context = HdfsContextCli()
    result = context.copy(params['src'], params['dest'])

    module.exit_json(changed=True, result=result)


if __name__ == '__main__':
    main()
